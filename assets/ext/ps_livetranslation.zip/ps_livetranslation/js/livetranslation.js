var _jipt = [];
_jipt.push(['project', 'prestashop-official']);
(function()
{
  var script = document.createElement('script');
  script.async = true;
  script.src = "//cdn.crowdin.net/jipt/jipt.js";
  document.getElementsByTagName('head')[0].appendChild(script);
})();
